package catalogue;

import java.io.Serializable;
import java.util.Collections;//needed for collections.sort


/**
 * The class BetterBasket aims to improve the user experience surrounding each instance of a basket:
 * 	- The basket items are sorted into ascending order, on their product key
 * 	- Multiple items of the same type are grouped into one request for a plural of the same product, rather than listed individually
 * 

 */
public class BetterBasket extends Basket implements Serializable
{
  private static final long serialVersionUID = 1L;

  @Override
  public boolean add (Product pro)
  {
	  //group together multiple items if they have the same type 
	  for (int x=0; x<this.size(); x++){
		  if(this.get(x).getProductNum().equals(pro.getProductNum())){
			  this.get(x).setQuantity(this.get(x).getQuantity() + pro.getQuantity());
			  return true; //if the item was already there then exit the add method as  
			  
		  }
	  }
	  
	  super.add(pro);
	  //successful sort
	  Collections.sort(this, BetterBasket::Sort); //betterbasket implies class, sort implies method
	  return true;
	  
  }	 
 
  public static int Sort (Product x, Product y) { //the method is called by Collections.sort. 
	  return x.getProductNum().compareTo(y.getProductNum());//compare to is passed as an int 
  }
  
  //improved method for removing items

  public boolean remove (Product pr)
  {
	  //check all items in the basket (i) to see if one matches the product code to remove
	  for (int x=0; x<this.size(); x++){
		  if(this.get(x).getProductNum().equals(pr.getProductNum())){ //if a match is found:
			  //subtract 1 from the product quantity
			  this.get(x).setQuantity(this.get(x).getQuantity() - pr.getQuantity());			  
			  if (this.get(x).getQuantity() <= 0){
				  super.remove(x);
			  }  
			  return true; //exit method
		  } 	  
	  }
	    
	  return false;
  }
  
  //method to check if item is within the basket
  
  public boolean checkList(Product pr)
  {
	  for (int x =0; x<this.size(); x++){
		  if(this.get(x).getProductNum().equals(pr.getProductNum())){
			  return true;
			  }
	  } 
	  return false;
  }
  
  
}
	  
  
