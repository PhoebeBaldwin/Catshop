package Feedback;
import catalogue.Basket;
import java.util.Observable;
import java.util.Observer;
import middle.MiddleFactory;
import middle.OrderProcessing;
import middle.StockReadWriter;

/**
 * Write a description of class FeedbackView here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FeedbackView implements Observer 
{
     private static final int H = 300;       // Height of window pixels
     private static final int W = 400;       // Width  of window 
     
     private final JLabel      theAction  = new JLabel();
     private final JTextField  theInput   = new JTextField();
     
     
    public FeedbackView()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
