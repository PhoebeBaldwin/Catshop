package clients.customer;
import java.io.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * The Customer Controller
 * @author M A Smith (c) June 2014
 */

public class CustomerController
{
  private CustomerModel model = null;
  private CustomerView  view  = null;
  private String FileName = "Stock.txt";
  private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss"); //timestamp function found at https://www.mkyong.com/java/how-to-get-current-timestamps-in-java/ 
 
  /**
   * Constructor
   * @param model The model 
   * @param view  The view from which the interaction came
   */
  public CustomerController( CustomerModel model, CustomerView view )
  {
    this.view  = view;
    this.model = model;
  }
  
  
  public void StockRequest(String Feedback){
    
     try{
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
         

            FileWriter fileWriter = new FileWriter(FileName,true);
            BufferedWriter BufferedWriter = new BufferedWriter(fileWriter);
            BufferedWriter.write(Feedback + " " + timestamp + " ");
            BufferedWriter.newLine(); 
            BufferedWriter.close();
        
     
    }
    catch(IOException ex){
        System.out.println(
        "Error writing to file '"
               + FileName + "'");
        
    }    
      
      
    }
    

  /**
   * Check interaction from view
   * @param pn The product number to be checked
   */
  public void doCheck( String pn )
  {
    model.doCheck(pn);
  }

  /**
   * Clear interaction from view
   */
  public void doClear()
  {
    model.doClear();
  }

  
}

